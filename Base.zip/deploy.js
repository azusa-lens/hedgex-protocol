// scripts/deploy.js
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const Market = await hre.ethers.getContractFactory("PredictionMarket");
  const market = await Market.deploy();
  await market.waitForDeployment();

  const addr = await market.getAddress();
  console.log("PredictionMarket deployed to:", addr);
  console.log("Base Sepolia explorer:", `https://sepolia.basescan.org/address/${addr}`);

  // Seed 3 starter markets
  const now = Math.floor(Date.now() / 1000);
  const day = 86400;

  const markets = [
    {
      question: "Will ETH be above $4000 by end of this week?",
      asset: "ETH",
      targetPrice: 4000n * 10n ** 8n,
      closeTime: now + day,
      resolveTime: now + day * 2
    },
    {
      question: "Will BTC reach $100k this month?",
      asset: "BTC",
      targetPrice: 100000n * 10n ** 8n,
      closeTime: now + day * 7,
      resolveTime: now + day * 8
    },
    {
      question: "Will ETH drop below $2500 this week?",
      asset: "ETH",
      targetPrice: 2500n * 10n ** 8n,
      closeTime: now + day * 3,
      resolveTime: now + day * 4
    }
  ];

  for (const m of markets) {
    const tx = await market.createMarket(
      m.question,
      m.asset,
      m.targetPrice,
      m.closeTime,
      m.resolveTime
    );
    await tx.wait();
    console.log(`Created market: "${m.question}"`);
  }

  console.log("\nDone! Add this to your .env:");
  console.log(`NEXT_PUBLIC_CONTRACT_ADDRESS=${addr}`);
  console.log(`NEXT_PUBLIC_CHAIN_ID=84532`);
}

main().catch((e) => { console.error(e); process.exit(1); });
